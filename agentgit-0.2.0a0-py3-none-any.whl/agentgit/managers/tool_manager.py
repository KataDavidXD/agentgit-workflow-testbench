"""Tool management extracted from RollbackAgent.

Handles tool registration, execution tracking, and rollback functionality.
"""

from typing import Optional, List, Dict, Any, Callable, Mapping
from datetime import datetime

from langchain_core.tools import BaseTool

from agentgit.core.rollback_protocol import (
    ToolRollbackRegistry,
    ToolSpec,
    ToolInvocationRecord,
    ReverseInvocationResult,
    CHECKPOINT_TOOL_NAMES,
)


class ToolManager:
    """Manages tool registration, tracking, and rollback operations.
    
    Extracted from RollbackAgent to follow Single Responsibility Principle.
    Handles reversible tool operations and maintains execution history.
    
    Attributes:
        tool_rollback_registry: Registry for tracking tool invocations.
        tools: List of available tools.
        _all_invocations: Tracks ALL tool invocations (not just reversible ones).
        
    Example:
        >>> manager = ToolManager(tools=[my_tool])
        >>> manager.register_reversible_tool("my_tool", reverse_fn)
        >>> manager.record_tool_invocation("my_tool", args, result)
    """
    
    def __init__(
        self,
        tools: Optional[List[BaseTool]] = None,
        reverse_tools: Optional[Mapping[str, Callable]] = None,
    ):
        """Initialize the tool manager.
        
        Args:
            tools: List of tools available to the agent.
            reverse_tools: Mapping of tool names to reverse functions.
        """
        self.tools = list(tools) if tools else []
        self.tool_rollback_registry = ToolRollbackRegistry()
        self._reverse_tools_map: Dict[str, Callable] = dict(reverse_tools or {})
        # Track ALL tool invocations (not just reversible ones) for statistics
        self._all_invocations: List[ToolInvocationRecord] = []
        
        # Register reversible tools
        self._register_reversible_tools()
    
    def _register_reversible_tools(self):
        """Register tools that have reverse handlers."""
        for tool in self.tools:
            tool_name = tool.name
            if tool_name in self._reverse_tools_map:
                reverse_fn = self._reverse_tools_map[tool_name]
                
                # Wrap forward function
                def _forward_wrapper(args: Mapping[str, Any], _tool=tool):
                    return _tool.invoke(args)
                
                self.tool_rollback_registry.register_tool(
                    ToolSpec(
                        name=tool_name, forward=_forward_wrapper, reverse=reverse_fn
                    )
                )
    
    def add_tools(self, tools: List[BaseTool]):
        """Add additional tools to the manager.
        
        Args:
            tools: List of tools to add.
        """
        self.tools.extend(tools)
    
    def register_reversible_tool(
        self,
        tool_name: str,
        forward_fn: Callable[[Mapping[str, Any]], Any],
        reverse_fn: Callable[[Mapping[str, Any], Any], Any],
    ):
        """Register a tool with its reverse handler.
        
        Args:
            tool_name: Name of the tool.
            forward_fn: Function that executes the tool.
            reverse_fn: Function that reverses the tool's effects.
        """
        self.tool_rollback_registry.register_tool(
            ToolSpec(name=tool_name, forward=forward_fn, reverse=reverse_fn)
        )
    
    def record_tool_invocation(
        self,
        tool_name: str,
        args: Dict[str, Any],
        result: Any,
        success: bool = True,
        error_message: Optional[str] = None,
    ):
        """Record a tool invocation for tracking and potential rollback.
        
        This method records ALL tool invocations for statistics, and additionally
        records reversible tools in the rollback registry.
        
        Args:
            tool_name: Name of the tool that was invoked.
            args: Arguments passed to the tool.
            result: Result from the tool execution.
            success: Whether the invocation succeeded.
            error_message: Optional error message if failed.
        """
        # Skip checkpoint management tools
        if tool_name in CHECKPOINT_TOOL_NAMES:
            return
        
        # Record ALL invocations for statistics (not just reversible)
        record = ToolInvocationRecord(
            tool_name=tool_name,
            args=args,
            result=result,
            success=success,
            error_message=error_message
        )
        self._all_invocations.append(record)
        
        # Additionally record in registry if tool is registered as reversible
        if self.tool_rollback_registry.get_tool(tool_name):
            self.tool_rollback_registry.record_invocation(
                tool_name, args, result, success, error_message
            )
    
    def get_tool_track(self) -> List[ToolInvocationRecord]:
        """Get the current tool invocation track (all tools, not just reversible).
        
        Returns:
            List of all tool invocation records.
        """
        return self._all_invocations
    
    def get_tool_track_position(self) -> int:
        """Get the current position in the tool track.
        
        Returns:
            Current track position (length of all invocations).
        """
        return len(self._all_invocations)
    
    def rollback_all_tools(self) -> List[ReverseInvocationResult]:
        """Rollback all recorded tool invocations.
        
        Executes reverse handlers in reverse order for all tracked tools.
        
        Returns:
            List of reverse invocation results.
        """
        return self.tool_rollback_registry.rollback()
    
    def rollback_tools_from_position(
        self, start_position: int
    ) -> List[ReverseInvocationResult]:
        """Rollback tools from a specific track position.
        
        Useful for rolling back to a checkpoint's tool track position.
        
        Args:
            start_position: Position to start rollback from.
            
        Returns:
            List of reverse invocation results.
        """
        track = self.tool_rollback_registry.get_track()
        results = []
        
        # Process in reverse order from end to start_position
        for i in range(len(track) - 1, start_position - 1, -1):
            record = track[i]
            tool_name = record.tool_name
            
            # Skip checkpoint tools
            if tool_name in CHECKPOINT_TOOL_NAMES:
                continue
            
            # Get the tool spec
            spec = self.tool_rollback_registry.get_tool(tool_name)
            if not spec or spec.reverse is None:
                results.append(
                    ReverseInvocationResult(
                        tool_name=tool_name,
                        reversed_successfully=False,
                        error_message="No reverse handler registered",
                    )
                )
                continue
            
            # Execute reverse handler
            try:
                spec.reverse(record.args, record.result)
                results.append(
                    ReverseInvocationResult(
                        tool_name=tool_name, reversed_successfully=True
                    )
                )
            except Exception as e:
                results.append(
                    ReverseInvocationResult(
                        tool_name=tool_name,
                        reversed_successfully=False,
                        error_message=str(e),
                    )
                )
        
        return results
    
    def redo_tools(self) -> List[ToolInvocationRecord]:
        """Re-execute forward handlers for recorded tools.
        
        Returns:
            List of new invocation records.
        """
        return self.tool_rollback_registry.redo()
    
    def clear_track(self):
        """Clear the tool invocation track.
        
        Clears both the all-invocations list and the rollback registry.
        Useful when starting a new session or after a successful rollback.
        """
        self._all_invocations.clear()
        self.tool_rollback_registry._track.clear()
    
    def restore_track_from_checkpoint(
        self, tool_invocations: List[Dict[str, Any]]
    ):
        """Restore tool track from checkpoint data.
        
        Restores both the all-invocations list and the rollback registry
        (for reversible tools only).
        
        Args:
            tool_invocations: List of tool invocation data from checkpoint.
        """
        self._all_invocations.clear()
        self.tool_rollback_registry._track.clear()
        
        for inv in tool_invocations:
            record = ToolInvocationRecord(
                tool_name=inv.get("tool_name"),
                args=inv.get("args", {}),
                result=inv.get("result"),
                success=inv.get("success", True),
                error_message=inv.get("error_message"),
            )
            # Add to all invocations
            self._all_invocations.append(record)
            
            # Add to rollback registry if tool is reversible
            if self.tool_rollback_registry.get_tool(record.tool_name):
                self.tool_rollback_registry._track.append(record)
    
    def get_tool_statistics(self) -> Dict[str, Any]:
        """Get statistics about tool usage.
        
        Returns:
            Dictionary with tool usage statistics.
        """
        track = self.get_tool_track()
        
        tool_counts = {}
        successful = 0
        failed = 0
        
        for record in track:
            tool_name = record.tool_name
            tool_counts[tool_name] = tool_counts.get(tool_name, 0) + 1
            
            if record.success:
                successful += 1
            else:
                failed += 1
        
        return {
            "total_invocations": len(track),
            "successful": successful,
            "failed": failed,
            "unique_tools": len(tool_counts),
            "tool_counts": tool_counts,
        }

