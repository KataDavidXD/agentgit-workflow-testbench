"""Node Manager for MDP-based workflows.

Handles the execution of workflow nodes and state management,
supporting both InternalSession_mdp and metadata-based storage.
"""

from typing import Dict, Any, Optional, List
from agentgit.core.workflow import WorkflowGraph, WorkflowNode
from agentgit.managers.tool_manager import ToolManager
from agentgit.sessions.internal_session import InternalSession
from agentgit.sessions.internal_session_mdp import InternalSession_mdp

class NodeManager:
    """Manages workflow execution and state.
    
    Acts as an orchestrator between the WorkflowGraph, ToolManager,
    and the Session state.
    """
    
    def __init__(self, workflow_graph: WorkflowGraph, tool_manager: ToolManager):
        """Initialize the NodeManager.
        
        Args:
            workflow_graph: The workflow definition.
            tool_manager: Manager for executing node logic (tools).
        """
        self.workflow = workflow_graph
        self.tool_manager = tool_manager
        
    def get_mdp_state(self, session: InternalSession) -> Dict[str, Any]:
        """Retrieve MDP state from session.
        
        Args:
            session: The internal session.
            
        Returns:
            Dictionary containing current_node_id, workflow_variables, execution_path.
        """
        if isinstance(session, InternalSession_mdp):
            return {
                "current_node_id": session.current_node_id or self.workflow.entry_point,
                "workflow_variables": session.workflow_variables,
                "execution_path": session.execution_path
            }
            
        # Fallback for base InternalSession using metadata
        default_state = {
            "current_node_id": self.workflow.entry_point,
            "workflow_variables": {},
            "execution_path": []
        }
        return session.metadata.get("mdp_state", default_state)
        
    def update_mdp_state(self, session: InternalSession, state: Dict[str, Any]):
        """Update MDP state in session.
        
        Args:
            session: The internal session.
            state: The new state dictionary.
        """
        if isinstance(session, InternalSession_mdp):
            session.current_node_id = state.get("current_node_id")
            session.workflow_variables = state.get("workflow_variables", {})
            session.execution_path = state.get("execution_path", [])
            
            # Sync session_state for generic tool compatibility
            session.session_state.update(session.workflow_variables)
        else:
            # Fallback
            session.metadata["mdp_state"] = state
            session.session_state.update(state.get("workflow_variables", {}))
        
    def execute_node(self, session: InternalSession) -> Dict[str, Any]:
        """Execute the current node's logic.
        
        Args:
            session: The internal session.
            
        Returns:
            The result of the node execution (outputs).
        """
        state = self.get_mdp_state(session)
        node_id = state["current_node_id"]
        
        if not node_id:
            raise ValueError("No current node defined in session state.")
            
        node = self.workflow.get_node(node_id)
        if not node:
            raise ValueError(f"Node {node_id} not found in workflow.")
            
        # Record execution in path
        state["execution_path"].append(node_id)
        self.update_mdp_state(session, state)
        
        # Prepare context
        context = state["workflow_variables"].copy()
        
        # Execute via ToolManager
        tool = next((t for t in self.tool_manager.tools if t.name == node.tool_name), None)
        if not tool:
            # Try finding in reverse_tools_map or other registries if needed
            # For now, assume strict tool existence
            raise ValueError(f"Tool '{node.tool_name}' not found in ToolManager.")
            
        # Execute
        try:
            result = tool.invoke(context)
            success = True
            error_msg = None
        except Exception as e:
            result = str(e)
            success = False
            error_msg = str(e)
            
        # Record in ToolManager for tracking/stats
        self.tool_manager.record_tool_invocation(
            tool_name=node.tool_name,
            args=context,
            result=result,
            success=success,
            error_message=error_msg
        )
        
        return result if success else {"error": result}

    def transition(self, session: InternalSession, execution_result: Any) -> Optional[str]:
        """Determine and set the next node.
        
        Args:
            session: The internal session.
            execution_result: Result from the previous node execution.
            
        Returns:
            The ID of the next node, or None if workflow ends.
        """
        state = self.get_mdp_state(session)
        current_node_id = state["current_node_id"]
        
        edges = self.workflow.get_outgoing_edges(current_node_id)
        next_node_id = None
        
        # Prepare context for conditions (vars + latest result)
        condition_context = state["workflow_variables"].copy()
        if isinstance(execution_result, dict):
            condition_context.update(execution_result)
        
        # Evaluate edges
        for edge in edges:
            if edge.condition_logic:
                # Look up condition logic (tool)
                condition_tool = next((t for t in self.tool_manager.tools if t.name == edge.condition_logic), None)
                if condition_tool:
                    try:
                        # Execute condition
                        cond_result = condition_tool.invoke(condition_context)
                        
                        # Evaluate truthiness
                        is_true = False
                        if isinstance(cond_result, bool):
                            is_true = cond_result
                        elif isinstance(cond_result, dict):
                            is_true = cond_result.get("result", False)
                            
                        if is_true:
                            next_node_id = edge.target_id
                            break
                    except Exception as e:
                        print(f"Error evaluating condition {edge.condition_logic}: {e}")
                        continue
            else:
                # Unconditional edge
                next_node_id = edge.target_id
                break
        
        # Update variables with result if applicable
        if isinstance(execution_result, dict):
            state["workflow_variables"].update(execution_result)
            
        if next_node_id:
            state["current_node_id"] = next_node_id
        # Note: If next_node_id is None, we leave current_node_id as is (the last executed node)
        
        # Always update state (variables changed)
        self.update_mdp_state(session, state)
            
        return next_node_id
