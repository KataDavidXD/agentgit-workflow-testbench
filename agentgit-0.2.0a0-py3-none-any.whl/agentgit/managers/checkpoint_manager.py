"""Checkpoint management extracted from RollbackAgent.

Handles all checkpoint-related operations including creation, listing,
deletion, and rollback functionality.
"""

from typing import Optional, List, Dict, Any
from datetime import datetime

from agentgit.checkpoints.checkpoint import Checkpoint
from agentgit.database.repositories.checkpoint_repository import CheckpointRepository
from agentgit.sessions.internal_session import InternalSession


class CheckpointManager:
    """Manages checkpoint operations for agent sessions.
    
    Extracted from RollbackAgent to follow Single Responsibility Principle.
    Handles checkpoint creation, retrieval, deletion, and cleanup.
    
    Attributes:
        checkpoint_repo: Repository for checkpoint persistence.
        
    Example:
        >>> manager = CheckpointManager(checkpoint_repo)
        >>> checkpoint = manager.create_checkpoint(
        ...     internal_session=session,
        ...     name="Before action",
        ...     is_auto=False
        ... )
    """
    
    def __init__(self, checkpoint_repo: Optional[CheckpointRepository] = None):
        """Initialize the checkpoint manager.
        
        Args:
            checkpoint_repo: Repository for checkpoint operations.
                           If None, creates a new instance.
        """
        self.checkpoint_repo = checkpoint_repo or CheckpointRepository()
    
    def create_checkpoint(
        self,
        internal_session: InternalSession,
        name: Optional[str] = None,
        is_auto: bool = False,
        tool_invocations: Optional[List[Dict[str, Any]]] = None,
        tool_track_position: int = 0,
        audit_trail: Optional[Any] = None,
    ) -> Optional[Checkpoint]:
        """Create a checkpoint from the current session state.
        
        Args:
            internal_session: The internal session to checkpoint.
            name: Optional name for the checkpoint.
            is_auto: Whether this is an automatic checkpoint.
            tool_invocations: Tool invocation history up to this point.
            tool_track_position: Position in the tool track.
            audit_trail: Optional audit trail to include in checkpoint.
            
        Returns:
            The created Checkpoint object, or None if failed.
        """
        if not internal_session or not internal_session.id:
            return None
        
        if not name:
            name = f"Checkpoint at {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}"
        
        checkpoint = Checkpoint.from_internal_session(
            internal_session,
            checkpoint_name=name,
            is_auto=is_auto,
            tool_invocations=tool_invocations or [],
            audit_trail=audit_trail,
        )
        
        # Store tool track position
        checkpoint.metadata["tool_track_position"] = tool_track_position
        
        # Save to database
        saved_checkpoint = self.checkpoint_repo.create(checkpoint)
        
        if saved_checkpoint:
            internal_session.checkpoint_count += 1
        
        return saved_checkpoint
    
    def list_checkpoints(
        self,
        internal_session_id: int,
        auto_only: bool = False,
    ) -> List[Checkpoint]:
        """List all checkpoints for a session.
        
        Args:
            internal_session_id: ID of the internal session.
            auto_only: If True, only return automatic checkpoints.
            
        Returns:
            List of Checkpoint objects.
        """
        return self.checkpoint_repo.get_by_internal_session(
            internal_session_id, auto_only=auto_only
        )
    
    def get_checkpoint(self, checkpoint_id: int) -> Optional[Checkpoint]:
        """Get a specific checkpoint by ID.
        
        Args:
            checkpoint_id: ID of the checkpoint to retrieve.
            
        Returns:
            Checkpoint object if found, None otherwise.
        """
        return self.checkpoint_repo.get_by_id(checkpoint_id)
    
    def get_checkpoint_by_name(
        self,
        internal_session_id: int,
        name: str,
    ) -> Optional[Checkpoint]:
        """Find a checkpoint by name.
        
        Args:
            internal_session_id: ID of the internal session.
            name: Name of the checkpoint to find.
            
        Returns:
            Checkpoint object if found, None otherwise.
        """
        checkpoints = self.checkpoint_repo.get_by_internal_session(internal_session_id)
        name_lower = name.lower()
        
        for cp in checkpoints:
            if cp.checkpoint_name and cp.checkpoint_name.lower() == name_lower:
                return cp
        
        return None
    
    def delete_checkpoint(
        self,
        checkpoint_id: int,
        internal_session_id: Optional[int] = None,
    ) -> bool:
        """Delete a checkpoint.
        
        Args:
            checkpoint_id: ID of the checkpoint to delete.
            internal_session_id: Optional session ID for validation.
            
        Returns:
            True if deletion successful, False otherwise.
        """
        if internal_session_id:
            checkpoint = self.checkpoint_repo.get_by_id(checkpoint_id)
            if not checkpoint or checkpoint.internal_session_id != internal_session_id:
                return False
        
        return self.checkpoint_repo.delete(checkpoint_id)
    
    def cleanup_auto_checkpoints(
        self,
        internal_session_id: int,
        keep_latest: int = 5,
    ) -> int:
        """Clean up old automatic checkpoints.
        
        Args:
            internal_session_id: ID of the internal session.
            keep_latest: Number of latest checkpoints to keep.
            
        Returns:
            Number of checkpoints deleted.
        """
        return self.checkpoint_repo.delete_auto_checkpoints(
            internal_session_id, keep_latest=keep_latest
        )
    
    def get_checkpoint_info(self, checkpoint_id: int) -> Optional[Dict[str, Any]]:
        """Get detailed information about a checkpoint.
        
        Args:
            checkpoint_id: ID of the checkpoint.
            
        Returns:
            Dictionary with checkpoint information, or None if not found.
        """
        checkpoint = self.checkpoint_repo.get_by_id(checkpoint_id)
        if not checkpoint:
            return None
        
        return {
            "id": checkpoint.id,
            "name": checkpoint.checkpoint_name or "Unnamed",
            "is_auto": checkpoint.is_auto,
            "created_at": checkpoint.created_at,
            "conversation_length": len(checkpoint.conversation_history),
            "tool_invocations": len(checkpoint.tool_invocations),
            "metadata": checkpoint.metadata,
        }
    
    def format_checkpoint_list(self, checkpoints: List[Checkpoint]) -> str:
        """Format a list of checkpoints for display.
        
        Args:
            checkpoints: List of Checkpoint objects.
            
        Returns:
            Formatted string for display.
        """
        if not checkpoints:
            return "No checkpoints found."
        
        result = "Available checkpoints:\n"
        for cp in checkpoints:
            checkpoint_type = "auto" if cp.is_auto else "manual"
            created = (
                cp.created_at.strftime("%Y-%m-%d %H:%M:%S")
                if cp.created_at
                else "unknown"
            )
            name = cp.checkpoint_name or "Unnamed"
            result += f"\n• ID: {cp.id} | {name} | Type: {checkpoint_type} | Created: {created}"
        
        return result
    
    def format_checkpoint_info(self, checkpoint_id: int) -> str:
        """Format checkpoint information for display.
        
        Args:
            checkpoint_id: ID of the checkpoint.
            
        Returns:
            Formatted string with checkpoint details.
        """
        info = self.get_checkpoint_info(checkpoint_id)
        if not info:
            return f"Checkpoint {checkpoint_id} not found."
        
        checkpoint_type = "Automatic" if info["is_auto"] else "Manual"
        created = (
            info["created_at"].strftime("%Y-%m-%d %H:%M:%S")
            if info["created_at"]
            else "unknown"
        )
        
        result = f"Checkpoint Details:\n"
        result += f"• ID: {info['id']}\n"
        result += f"• Name: {info['name']}\n"
        result += f"• Type: {checkpoint_type}\n"
        result += f"• Created: {created}\n"
        result += f"• Conversation Length: {info['conversation_length']} messages"
        
        return result

