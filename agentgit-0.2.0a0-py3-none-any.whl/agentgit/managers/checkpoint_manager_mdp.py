"""Checkpoint Manager for MDP-based workflows.

Extends the base CheckpointManager to support hierarchical checkpoints
(Node vs Tool/Message) using existing data structures (metadata).
"""

from typing import Optional, Dict, Any, List
from agentgit.managers.checkpoint_manager import CheckpointManager
from agentgit.checkpoints.checkpoint import Checkpoint
from agentgit.sessions.internal_session_mdp import InternalSession_mdp

class CheckpointManager_mdp(CheckpointManager):
    """Extended CheckpointManager for MDP workflows.
    
    Uses the 'metadata' field of Checkpoints to store type information
    (NODE vs TOOL_MESSAGE) and hierarchy links.
    """
    
    def create_node_checkpoint(
        self, 
        internal_session: InternalSession_mdp, 
        node_id: str,
        workflow_version: str,
        tool_track_position: int = 0
    ) -> Optional[Checkpoint]:
        """Create a checkpoint at the Node level.
        
        Args:
            internal_session: The session.
            node_id: The current workflow node ID.
            workflow_version: Version of the workflow.
            tool_track_position: Current position in the tool track.
            
        Returns:
            The created checkpoint.
        """
        name = f"Node: {node_id}"
        
        # Capture MDP state into metadata
        mdp_state = {
            "current_node_id": node_id,
            "workflow_variables": internal_session.workflow_variables.copy(),
            "execution_path": internal_session.execution_path.copy()
        }
        
        checkpoint = self.create_checkpoint(
            internal_session=internal_session,
            name=name,
            is_auto=True,
            tool_track_position=tool_track_position
        )
        
        if checkpoint:
            checkpoint.metadata.update({
                "checkpoint_type": "node",
                "node_id": node_id,
                "workflow_version": workflow_version,
                "mdp_state": mdp_state,
                "child_checkpoint_ids": []
            })
            self.checkpoint_repo.update_checkpoint_metadata(checkpoint.id, checkpoint.metadata)
            
        return checkpoint

    def create_tool_message_checkpoint(
        self, 
        internal_session: InternalSession_mdp, 
        parent_checkpoint_id: int,
        tool_track_position: int = 0
    ) -> Optional[Checkpoint]: # 小颗粒度的checkpoints （old checkpoints）
        """Create a fine-grained checkpoint for tool/message steps.
        
        Args:
            internal_session: The session.
            parent_checkpoint_id: ID of the enclosing Node checkpoint.
            tool_track_position: Current position in the tool track.
            
        Returns:
            The created checkpoint.
        """
        
        # Capture MDP state into metadata (Same as Node Checkpoint)
        mdp_state = {
            "current_node_id": internal_session.current_node_id,
            "workflow_variables": internal_session.workflow_variables.copy(),
            "execution_path": internal_session.execution_path.copy()
        }

        checkpoint = self.create_checkpoint(
            internal_session=internal_session,
            name="Tool/Message Step",
            is_auto=True,
            tool_track_position=tool_track_position
        )
        
        if checkpoint:
            checkpoint.metadata.update({
                "checkpoint_type": "tool_message",
                "parent_checkpoint_id": parent_checkpoint_id,
                "mdp_state": mdp_state,
                "node_id": internal_session.current_node_id,  # Also set top-level for easy access
                "workflow_version": internal_session.workflow_version_id or "1.0.0"
            })
            self.checkpoint_repo.update_checkpoint_metadata(checkpoint.id, checkpoint.metadata)
            
            # Link to parent
            parent = self.get_checkpoint(parent_checkpoint_id)
            if parent:
                children = parent.metadata.get("child_checkpoint_ids", [])
                children.append(checkpoint.id)
                parent.metadata["child_checkpoint_ids"] = children
                self.checkpoint_repo.update_checkpoint_metadata(parent.id, parent.metadata)
                
        return checkpoint
        
    def get_node_checkpoints(self, internal_session_id: int) -> List[Checkpoint]:
        """Get only node-level checkpoints for a session.
        
        Args:
            internal_session_id: Session ID.
            
        Returns:
            List of node checkpoints.
        """
        all_checkpoints = self.list_checkpoints(internal_session_id)
        return [
            cp for cp in all_checkpoints 
            if cp.metadata.get("checkpoint_type") == "node"
        ]

# goal: community adoption, liability  ->  list issues【】

# abandoned plan - issue: branch is ok, when rolling back, 基本上以前的所有rollback逻辑都broke，变成了两套无关的rollback逻辑，卡在这儿了 -》 ask ai - ai fucked up 






# new version 

# 用户上传workflow -》自己分解贮存workflow NOT langgrapg.workflow  >= | invoke.(workflow)
# langgraph workflow -> @ helper -> 我们的style [todo]

# interaction - tool/message: tool_message 

# agent workflow - 整个业务， 业务： 10 funcs -》 10 nodes, 单次业务做完了；第二次业务跑起来的时候怎么做， |workfow graph|

# node 颗粒度 (node checkpoint + node child: tool_message checkpoint)  
 
# archiv search [user input, wait []]  - analysis (anay 1 , anay2  ) -disucssion 
# node 1 - node 2 (tool 1 , message 1 -> tool 2) - node 3  | node 1+ tool 1 in node 2 

# node (await [external api respond])

# old 颗粒度  - full snapshot- only cares old checkpoint & rollback 

# 提高颗粒度 - node 
# 每个颗粒度有自己的系统


# Version 0.1 agent ide : demo case - cot case | reflection ide, reflection(error, path) -> new plan
# Version 0.2 agent ide: graph + cot 
# Version 0.3 mas

# arxiv search agent, tool: search api, read pdf, analysis topic, discussion, summerize,


'''
input: tool pool with 5 tools+ description, llm select and plan tools -> action plan 


tools数量+ description > 上下文窗口，表现exp下降
solution：  create rollback agent (小颗粒度可以per 交互，回退的agent) with only useful tools at this stage \ next stage, inherit and recreate new agenent with new tools 
solution workflow: 

1. User 提出问题，tool Pools (n tools) 
2. tools & question -> llm -> action plan（工作流，根据这些工具和业务需求，需要一个工作流，完成这个工作流，需要几步，每步需要什么工具）, ex. three stages, each stages with their own tools （tool_stage 1）
3. psuedo workflow (agent git外，不要在agent git里面写，agent testing同级的service) (given plan, step by step create agent and run): 手动创建session，参考example；
    agent 创建 + agent对话（真实场景await user response） -》create checkpoints -》new agent创建 with new tools in stage 2 
4. * reflection : error, 显示error中断， 判断： error+audit 历史 + tools ——》 llm -》llm check， 是否计划出了问题，还是工具需要调整，
如果是计划有问题 ——》重新创建计划——》回到1.
如果是里面某个stage 有问题——》rollback to stage里 某个tool/messge 之前 （agent git rollback）
如果tool写的有问题 （debug tool/让用户debug tool）

plan service 

psuedo workflow service ( compile agent + user invoke + create checkpoiunt +  resume with new tools)

relection service (error extraction + llm reflection + rollback (if 里面某个stage 有问题) +  * debug )

'''