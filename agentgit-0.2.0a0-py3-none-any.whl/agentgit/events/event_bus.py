"""Event bus for domain events.

Provides a simple publish-subscribe mechanism for decoupling components
through domain events.
"""

from typing import Dict, List, Callable, Any, Type
from dataclasses import dataclass
from datetime import datetime
from abc import ABC


class DomainEvent(ABC):
    """Base class for all domain events.
    
    Domain events represent things that have happened in the system.
    They are immutable and carry information about the occurrence.
    
    Attributes:
        timestamp: When the event occurred.
        event_id: Unique identifier for the event.
    """
    
    def __init__(self, timestamp: datetime, event_id: str = ""):
        """Initialize domain event.
        
        Args:
            timestamp: When the event occurred.
            event_id: Optional unique identifier for the event.
        """
        self.timestamp = timestamp
        if not event_id:
            import uuid
            self.event_id = f"{self.__class__.__name__}_{uuid.uuid4().hex[:8]}"
        else:
            self.event_id = event_id


class EventBus:
    """Simple event bus for publish-subscribe pattern.
    
    Allows components to communicate without direct dependencies by
    publishing and subscribing to domain events.
    
    Example:
        >>> bus = EventBus()
        >>> 
        >>> # Subscribe to events
        >>> def handle_checkpoint_created(event: CheckpointCreatedEvent):
        ...     print(f"Checkpoint {event.checkpoint_id} created")
        >>> 
        >>> bus.subscribe(CheckpointCreatedEvent, handle_checkpoint_created)
        >>> 
        >>> # Publish event
        >>> event = CheckpointCreatedEvent(
        ...     timestamp=datetime.now(),
        ...     checkpoint_id=1,
        ...     session_id=100
        ... )
        >>> bus.publish(event)
    """
    
    def __init__(self):
        """Initialize the event bus."""
        self._subscribers: Dict[Type[DomainEvent], List[Callable]] = {}
        self._event_history: List[DomainEvent] = []
        self._max_history = 100  # Limit history to prevent memory issues
    
    def subscribe(self, event_type: Type[DomainEvent], handler: Callable[[DomainEvent], None]):
        """Subscribe a handler to an event type.
        
        Args:
            event_type: The type of event to subscribe to.
            handler: Function to call when event is published.
                    Should accept one argument (the event).
        """
        if event_type not in self._subscribers:
            self._subscribers[event_type] = []
        
        self._subscribers[event_type].append(handler)
    
    def unsubscribe(self, event_type: Type[DomainEvent], handler: Callable):
        """Unsubscribe a handler from an event type.
        
        Args:
            event_type: The type of event to unsubscribe from.
            handler: The handler function to remove.
        """
        if event_type in self._subscribers:
            self._subscribers[event_type] = [
                h for h in self._subscribers[event_type] if h != handler
            ]
    
    def publish(self, event: DomainEvent):
        """Publish an event to all subscribers.
        
        Args:
            event: The event to publish.
        """
        # Store in history
        self._event_history.append(event)
        if len(self._event_history) > self._max_history:
            self._event_history.pop(0)
        
        # Notify subscribers
        event_type = type(event)
        if event_type in self._subscribers:
            for handler in self._subscribers[event_type]:
                try:
                    handler(event)
                except Exception as e:
                    # Log error but don't stop other handlers
                    print(f"Error in event handler for {event_type.__name__}: {e}")
    
    def publish_all(self, events: List[DomainEvent]):
        """Publish multiple events.
        
        Args:
            events: List of events to publish.
        """
        for event in events:
            self.publish(event)
    
    def get_event_history(self, event_type: Type[DomainEvent] = None) -> List[DomainEvent]:
        """Get event history, optionally filtered by type.
        
        Args:
            event_type: Optional event type to filter by.
            
        Returns:
            List of events from history.
        """
        if event_type is None:
            return self._event_history.copy()
        
        return [e for e in self._event_history if isinstance(e, event_type)]
    
    def clear_history(self):
        """Clear the event history."""
        self._event_history.clear()
    
    def clear_subscribers(self):
        """Clear all subscribers."""
        self._subscribers.clear()
    
    def get_subscriber_count(self, event_type: Type[DomainEvent] = None) -> int:
        """Get the number of subscribers.
        
        Args:
            event_type: Optional event type to count subscribers for.
                       If None, returns total subscriber count.
            
        Returns:
            Number of subscribers.
        """
        if event_type is None:
            return sum(len(handlers) for handlers in self._subscribers.values())
        
        return len(self._subscribers.get(event_type, []))


# Global event bus instance (optional convenience)
_global_event_bus: EventBus = None


def get_global_event_bus() -> EventBus:
    """Get the global event bus instance.
    
    Creates one if it doesn't exist.
    
    Returns:
        The global EventBus instance.
    """
    global _global_event_bus
    if _global_event_bus is None:
        _global_event_bus = EventBus()
    return _global_event_bus


def set_global_event_bus(bus: EventBus):
    """Set the global event bus instance.
    
    Args:
        bus: The EventBus instance to use globally.
    """
    global _global_event_bus
    _global_event_bus = bus

