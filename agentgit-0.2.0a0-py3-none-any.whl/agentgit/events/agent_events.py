"""Domain events for agent operations.

Defines specific events that occur during agent lifecycle and operations.
"""

from datetime import datetime
from typing import Optional, Dict, Any

from agentgit.events.event_bus import DomainEvent


class CheckpointCreatedEvent(DomainEvent):
    """Event published when a checkpoint is created.
    
    Attributes:
        checkpoint_id: ID of the created checkpoint.
        session_id: ID of the internal session.
        checkpoint_name: Name of the checkpoint.
        is_auto: Whether this was an automatic checkpoint.
        tool_count: Number of tool invocations at checkpoint time.
    """
    
    def __init__(
        self,
        timestamp: datetime,
        checkpoint_id: int,
        session_id: int,
        checkpoint_name: Optional[str] = None,
        is_auto: bool = False,
        tool_count: int = 0,
        event_id: str = "",
    ):
        super().__init__(timestamp, event_id)
        self.checkpoint_id = checkpoint_id
        self.session_id = session_id
        self.checkpoint_name = checkpoint_name
        self.is_auto = is_auto
        self.tool_count = tool_count


class CheckpointDeletedEvent(DomainEvent):
    """Event published when a checkpoint is deleted.
    
    Attributes:
        checkpoint_id: ID of the deleted checkpoint.
        session_id: ID of the internal session.
    """
    
    def __init__(
        self,
        timestamp: datetime,
        checkpoint_id: int,
        session_id: int,
        event_id: str = "",
    ):
        super().__init__(timestamp, event_id)
        self.checkpoint_id = checkpoint_id
        self.session_id = session_id


class ToolExecutedEvent(DomainEvent):
    """Event published when a tool is executed.
    
    Attributes:
        tool_name: Name of the executed tool.
        args: Arguments passed to the tool.
        result: Result from the tool execution.
        success: Whether the execution succeeded.
        error_message: Error message if execution failed.
        duration_ms: Execution duration in milliseconds.
    """
    
    def __init__(
        self,
        timestamp: datetime,
        tool_name: str,
        args: Dict[str, Any],
        result: Any = None,
        success: bool = True,
        error_message: Optional[str] = None,
        duration_ms: Optional[float] = None,
        event_id: str = "",
    ):
        super().__init__(timestamp, event_id)
        self.tool_name = tool_name
        self.args = args
        self.result = result
        self.success = success
        self.error_message = error_message
        self.duration_ms = duration_ms


class ToolReversedEvent(DomainEvent):
    """Event published when a tool operation is reversed.
    
    Attributes:
        tool_name: Name of the reversed tool.
        success: Whether the reversal succeeded.
        error_message: Error message if reversal failed.
    """
    
    def __init__(
        self,
        timestamp: datetime,
        tool_name: str,
        success: bool = True,
        error_message: Optional[str] = None,
        event_id: str = "",
    ):
        super().__init__(timestamp, event_id)
        self.tool_name = tool_name
        self.success = success
        self.error_message = error_message


class SessionCreatedEvent(DomainEvent):
    """Event published when a session is created.
    
    Attributes:
        session_id: ID of the created session.
        external_session_id: ID of the parent external session.
        is_branch: Whether this is a branched session.
        parent_session_id: ID of parent session (if branch).
    """
    
    def __init__(
        self,
        timestamp: datetime,
        session_id: int,
        external_session_id: int,
        is_branch: bool = False,
        parent_session_id: Optional[int] = None,
        event_id: str = "",
    ):
        super().__init__(timestamp, event_id)
        self.session_id = session_id
        self.external_session_id = external_session_id
        self.is_branch = is_branch
        self.parent_session_id = parent_session_id


class RollbackPerformedEvent(DomainEvent):
    """Event published when a rollback is performed.
    
    Attributes:
        checkpoint_id: ID of the checkpoint rolled back to.
        original_session_id: ID of the original session.
        new_session_id: ID of the new branched session.
        tools_reversed: Number of tools that were reversed.
    """
    
    def __init__(
        self,
        timestamp: datetime,
        checkpoint_id: int,
        original_session_id: int,
        new_session_id: int,
        tools_reversed: int = 0,
        event_id: str = "",
    ):
        super().__init__(timestamp, event_id)
        self.checkpoint_id = checkpoint_id
        self.original_session_id = original_session_id
        self.new_session_id = new_session_id
        self.tools_reversed = tools_reversed

