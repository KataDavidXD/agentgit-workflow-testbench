"""Audit trail system for tracking and monitoring agent operations.

This module provides comprehensive logging and tracking capabilities for LangGraph agents,
capturing tool executions, LLM calls, errors, and system events with timing information
and user-friendly formatting.

The audit trail system enables:
- Real-time operation monitoring
- Error tracking and debugging
- Performance analysis with timing metrics
- User-friendly event visualization
- Persistent audit logs for compliance

Classes:
    EventType: Enumeration of audit event types
    EventSeverity: Severity levels for categorizing events
    AuditEvent: Single recorded event with metadata
    AuditTrail: Collection and manager for audit events

Example:
    >>> from agentgit.audit.audit_trail import AuditTrail, AuditEvent, EventType, EventSeverity
    >>> from datetime import datetime
    >>>
    >>> # Create audit trail
    >>> trail = AuditTrail(session_id="session_123")
    >>>
    >>> # Add event
    >>> event = AuditEvent(
    ...     timestamp=datetime.now(),
    ...     event_type=EventType.TOOL_SUCCESS,
    ...     severity=EventSeverity.SUCCESS,
    ...     message="Tool executed successfully",
    ...     duration_ms=150.5
    ... )
    >>> trail.add_event(event)
    >>>
    >>> # Display formatted output
    >>> print(trail.format_user_display())
"""

from dataclasses import dataclass, field
from datetime import datetime
from typing import Optional, List, Dict, Any
from enum import Enum


class EventType(Enum):
    """Types of events that can be recorded in the audit trail.

    Attributes:
        TOOL_START: Tool execution initiated
        TOOL_SUCCESS: Tool completed successfully
        TOOL_ERROR: Tool execution failed with error
        AGENT_DECISION: Agent decided to use specific tools
        LLM_CALL: Language model invoked
        CHECKPOINT_CREATED: Checkpoint saved to database
        ROLLBACK: Session rolled back to previous checkpoint
    """
    TOOL_START = "tool_start"
    TOOL_SUCCESS = "tool_success"
    TOOL_ERROR = "tool_error"
    AGENT_DECISION = "agent_decision"
    LLM_CALL = "llm_call"
    CHECKPOINT_CREATED = "checkpoint_created"
    ROLLBACK = "rollback"


class EventSeverity(Enum):
    """Severity levels for categorizing audit events.

    Used to prioritize and filter events by importance.

    Attributes:
        INFO: Informational event (normal operation)
        WARNING: Warning event (potential issue)
        ERROR: Error event (operation failed)
        SUCCESS: Successful operation completion
    """
    INFO = "info"
    WARNING = "warning"
    ERROR = "error"
    SUCCESS = "success"


@dataclass
class AuditEvent:
    """Single event record in the audit trail.

    Captures a specific operation or occurrence during agent execution,
    including timing, severity, and contextual details.

    Attributes:
        timestamp: When the event occurred
        event_type: Type of event (from EventType enum)
        severity: Severity level (from EventSeverity enum)
        message: Human-readable event description
        details: Additional contextual information as key-value pairs
        error: Error message if event represents a failure (optional)
        duration_ms: Event duration in milliseconds (optional)

    Example:
        >>> event = AuditEvent(
        ...     timestamp=datetime.now(),
        ...     event_type=EventType.TOOL_SUCCESS,
        ...     severity=EventSeverity.SUCCESS,
        ...     message="Calculator tool completed",
        ...     details={"tool_name": "calculate_sum", "result": 42},
        ...     duration_ms=125.3
        ... )
    """
    timestamp: datetime
    event_type: EventType
    severity: EventSeverity
    message: str
    details: Dict[str, Any] = field(default_factory=dict)
    error: Optional[str] = None
    duration_ms: Optional[float] = None

    def to_dict(self) -> Dict[str, Any]:
        """Convert event to dictionary representation for serialization.

        Returns:
            Dictionary containing all event data with ISO-formatted timestamp

        Example:
            >>> event.to_dict()
            {
                'timestamp': '2025-01-14T10:30:45.123456',
                'event_type': 'tool_success',
                'severity': 'success',
                'message': 'Tool completed',
                'details': {'tool_name': 'my_tool'},
                'error': None,
                'duration_ms': 150.5
            }
        """
        return {
            "timestamp": self.timestamp.isoformat(),
            "event_type": self.event_type.value,
            "severity": self.severity.value,
            "message": self.message,
            "details": self.details,
            "error": self.error,
            "duration_ms": self.duration_ms
        }

    def format_user_friendly(self) -> str:
        """Format event for user-friendly console display.

        Produces a single-line or multi-line formatted string with:
        - Timestamp in HH:MM:SS format
        - Severity icon (ℹ️/✅/⚠️/❌)
        - Message description
        - Duration (if available)
        - Error details (if applicable, on separate line)

        Returns:
            Formatted string ready for console output

        Example:
            >>> print(event.format_user_friendly())
            [10:30:45] ✅ Tool 'calculate_sum' completed successfully (150ms)
        """
        time_str = self.timestamp.strftime("%H:%M:%S")
        severity_icon = {
            EventSeverity.INFO: "ℹ️",
            EventSeverity.SUCCESS: "✅",
            EventSeverity.WARNING: "⚠️",
            EventSeverity.ERROR: "❌"
        }[self.severity]

        msg = f"[{time_str}] {severity_icon} {self.message}"

        if self.duration_ms:
            msg += f" ({self.duration_ms:.0f}ms)"

        if self.error:
            msg += f"\n   └─ Error: {self.error}"

        return msg


@dataclass
class AuditTrail:
    """Collection and manager for audit events in an agent session.

    Provides centralized storage, querying, and formatting of audit events
    throughout an agent's lifecycle. Supports filtering by event type,
    summary statistics, and user-friendly display formatting.

    Attributes:
        events: Ordered list of all recorded events
        session_id: Unique identifier for the associated session (optional)

    Example:
        >>> trail = AuditTrail(session_id="langgraph_abc123")
        >>>
        >>> # Add events
        >>> trail.add_event(tool_start_event)
        >>> trail.add_event(tool_success_event)
        >>>
        >>> # Query events
        >>> errors = trail.get_errors()
        >>> summary = trail.get_summary()
        >>>
        >>> # Display
        >>> print(trail.format_user_display())
    """
    events: List[AuditEvent] = field(default_factory=list)
    session_id: Optional[str] = None

    def add_event(self, event: AuditEvent):
        """Add a new event to the audit trail.

        Events are appended chronologically to maintain temporal ordering.

        Args:
            event: AuditEvent instance to record

        Example:
            >>> trail.add_event(AuditEvent(
            ...     timestamp=datetime.now(),
            ...     event_type=EventType.TOOL_START,
            ...     severity=EventSeverity.INFO,
            ...     message="Tool execution started"
            ... ))
        """
        self.events.append(event)

    def get_errors(self) -> List[AuditEvent]:
        """Retrieve all events with ERROR severity.

        Useful for debugging and error analysis.

        Returns:
            List of AuditEvent instances with EventSeverity.ERROR

        Example:
            >>> errors = trail.get_errors()
            >>> for error in errors:
            ...     print(f"{error.message}: {error.error}")
        """
        return [e for e in self.events if e.severity == EventSeverity.ERROR]

    def get_tool_events(self) -> List[AuditEvent]:
        """Retrieve all tool-related events (start, success, error).

        Returns:
            List of AuditEvent instances with tool-related event types

        Example:
            >>> tool_events = trail.get_tool_events()
            >>> print(f"Total tool operations: {len(tool_events)}")
        """
        return [e for e in self.events
                if e.event_type in [EventType.TOOL_START, EventType.TOOL_SUCCESS, EventType.TOOL_ERROR]]

    def get_summary(self) -> Dict[str, Any]:
        """Generate summary statistics for all recorded events.

        Provides counts of:
        - Total events
        - Errors
        - Tool calls (started)
        - Successful tool calls
        - Failed tool calls
        - Checkpoints created

        Returns:
            Dictionary with summary statistics

        Example:
            >>> summary = trail.get_summary()
            >>> print(f"Success rate: {summary['successful_tools']}/{summary['tool_calls']}")
            Success rate: 8/10
        """
        return {
            "total_events": len(self.events),
            "errors": len(self.get_errors()),
            "tool_calls": len([e for e in self.events if e.event_type == EventType.TOOL_START]),
            "successful_tools": len([e for e in self.events if e.event_type == EventType.TOOL_SUCCESS]),
            "failed_tools": len([e for e in self.events if e.event_type == EventType.TOOL_ERROR]),
            "checkpoints": len([e for e in self.events if e.event_type == EventType.CHECKPOINT_CREATED])
        }

    def format_user_display(self, show_all: bool = False) -> str:
        """Format entire audit trail for user-friendly display.

        Produces a formatted report with:
        - Header
        - Summary statistics
        - Recent events (last 20 by default, or all if show_all=True)
        - Event count indicator if truncated

        Args:
            show_all: If True, display all events. If False, show last 20 (default: False)

        Returns:
            Multi-line formatted string ready for console output

        Example:
            >>> # Show recent events
            >>> print(trail.format_user_display())
            === Audit Trail ===

            Total Events: 45
            Tool Calls: 10 (✅ 8 | ❌ 2)
            Checkpoints Created: 3

            Recent Events:
            [10:30:45] ℹ️ Tool 'calculate_sum' started
            [10:30:46] ✅ Tool 'calculate_sum' completed successfully (150ms)
            ...

            >>> # Show all events
            >>> print(trail.format_user_display(show_all=True))
        """
        if not self.events:
            return "No events recorded yet."

        output = "=== Audit Trail ===\n\n"

        # Show summary
        summary = self.get_summary()
        output += f"Total Events: {summary['total_events']}\n"
        output += f"Tool Calls: {summary['tool_calls']} "
        output += f"(✅ {summary['successful_tools']} | ❌ {summary['failed_tools']})\n"
        output += f"Checkpoints Created: {summary['checkpoints']}\n"
        if summary['errors'] > 0:
            output += f"⚠️ Errors: {summary['errors']}\n"
        output += "\n"

        # Show events
        output += "Recent Events:\n"
        events_to_show = self.events if show_all else self.events[-20:]  # Last 20 by default

        for event in events_to_show:
            output += event.format_user_friendly() + "\n"

        if not show_all and len(self.events) > 20:
            output += f"\n... ({len(self.events) - 20} more events)\n"

        return output

    def to_dict(self) -> Dict[str, Any]:
        """Convert entire audit trail to dictionary for storage/serialization.

        Includes all events and summary statistics.

        Returns:
            Dictionary with session_id, events list, and summary

        Example:
            >>> import json
            >>> trail_data = trail.to_dict()
            >>> json.dumps(trail_data, indent=2)
        """
        return {
            "session_id": self.session_id,
            "events": [e.to_dict() for e in self.events],
            "summary": self.get_summary()
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "AuditTrail":
        """Reconstruct an AuditTrail from dictionary data.

        Deserializes an audit trail that was previously saved with to_dict().
        Useful for loading historical audit trails from checkpoints.

        Args:
            data: Dictionary containing audit trail data (from to_dict())

        Returns:
            AuditTrail instance with all events reconstructed

        Example:
            >>> # Load from checkpoint metadata
            >>> checkpoint = checkpoint_repo.get_by_id(checkpoint_id)
            >>> trail_data = checkpoint.metadata["audit_trail"]
            >>> trail = AuditTrail.from_dict(trail_data)
            >>> print(trail.format_user_display())
        """
        session_id = data.get("session_id")
        events_data = data.get("events", [])

        # Reconstruct events
        events = []
        for event_dict in events_data:
            event = AuditEvent(
                timestamp=datetime.fromisoformat(event_dict["timestamp"]),
                event_type=EventType(event_dict["event_type"]),
                severity=EventSeverity(event_dict["severity"]),
                message=event_dict["message"],
                details=event_dict.get("details", {}),
                error=event_dict.get("error"),
                duration_ms=event_dict.get("duration_ms")
            )
            events.append(event)

        return cls(events=events, session_id=session_id)