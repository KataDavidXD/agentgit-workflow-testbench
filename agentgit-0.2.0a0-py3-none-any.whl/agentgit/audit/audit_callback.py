"""LangChain callback handler for audit trail integration.

This module provides a callback handler that automatically captures and records
all agent operations (tool calls, LLM invocations, errors) into an audit trail.
Integrates seamlessly with LangChain's callback system for zero-overhead monitoring.

The callback system captures:
- Tool executions with timing and I/O
- LLM calls with model decisions
- Errors with formatted messages
- Performance metrics

Classes:
    AuditTrailCallback: LangChain callback handler for audit trail recording

Example:
    >>> from agentgit.audit.audit_trail import AuditTrail
    >>> from agentgit.audit.audit_callback import AuditTrailCallback
    >>> from langchain_core.callbacks import CallbackManager
    >>>
    >>> # Create audit trail and callback
    >>> trail = AuditTrail(session_id="session_123")
    >>> callback = AuditTrailCallback(trail)
    >>>
    >>> # Use with LangChain model
    >>> response = model.invoke(
    ...     messages,
    ...     config={"callbacks": [callback]}
    ... )
    >>>
    >>> # View captured events
    >>> print(trail.format_user_display())
"""

from langchain_core.callbacks import BaseCallbackHandler
from typing import Any, Dict, List, Optional
from datetime import datetime
import time

from agentgit.audit.audit_trail import (
    AuditTrail, AuditEvent, EventType, EventSeverity
)


class AuditTrailCallback(BaseCallbackHandler):
    """LangChain callback handler that captures agent operations for audit trail.

    Automatically records all tool executions, LLM calls, and errors to an
    AuditTrail instance. Measures operation durations and formats user-friendly
    error messages.

    This callback is designed to be used with LangChain models and tools via
    the standard callback mechanism. It maintains timing state internally to
    calculate operation durations.

    Attributes:
        audit_trail: AuditTrail instance where events are recorded
        _tool_start_times: Internal mapping of run_id to start time for tools
        _llm_start_times: Internal mapping of run_id to start time for LLM calls

    Example:
        >>> # Basic usage
        >>> trail = AuditTrail()
        >>> callback = AuditTrailCallback(trail)
        >>>
        >>> # With LangChain model
        >>> from langchain_openai import ChatOpenAI
        >>> model = ChatOpenAI()
        >>> response = model.invoke(
        ...     "Hello",
        ...     config={"callbacks": [callback]}
        ... )
        >>>
        >>> # Check recorded events
        >>> print(trail.get_summary())
    """

    def __init__(self, audit_trail: AuditTrail):
        """Initialize callback handler with an audit trail instance.

        Args:
            audit_trail: AuditTrail instance to record events to

        Example:
            >>> trail = AuditTrail(session_id="my_session")
            >>> callback = AuditTrailCallback(trail)
        """
        super().__init__()
        self._tool_names: Dict[str, str] = {}
        self.audit_trail = audit_trail
        self._tool_start_times: Dict[str, float] = {}
        self._llm_start_times: Dict[str, float] = {}

    # ==================== Tool Events ====================

    def on_tool_start(
        self,
        serialized: Dict[str, Any],
        input_str: str,
        run_id: Any,
        **kwargs: Any
    ) -> None:
        """Called when a tool starts executing.

        Records tool start event and begins timing for duration calculation.

        Args:
            serialized: Serialized tool metadata (contains tool name)
            input_str: Input string passed to the tool
            run_id: Unique identifier for this tool execution
            **kwargs: Additional keyword arguments from LangChain

        Note:
            This is called automatically by LangChain's callback system.
        """
        tool_name = serialized.get("name", "unknown_tool")

        # Record start time
        self._tool_start_times[str(run_id)] = time.time()
        self._tool_names[str(run_id)] = tool_name
        # Create event
        event = AuditEvent(
            timestamp=datetime.now(),
            event_type=EventType.TOOL_START,
            severity=EventSeverity.INFO,
            message=f"Tool '{tool_name}' started",
            details={
                "tool_name": tool_name,
                "input": input_str,
                "run_id": str(run_id)
            }
        )

        self.audit_trail.add_event(event)

    def on_tool_end(
        self,
        output: str,
        run_id: Any,
        **kwargs: Any
    ) -> None:
        """Called when a tool finishes successfully.

        Records tool success event with duration and output.

        Args:
            output: Output string returned by the tool
            run_id: Unique identifier for this tool execution
            **kwargs: Additional keyword arguments (may contain 'name')

        Note:
            This is called automatically by LangChain's callback system.
            Output is truncated to 200 characters for readability.
        """
        # Calculate duration
        duration_ms = None
        if str(run_id) in self._tool_start_times:
            duration_ms = (time.time() - self._tool_start_times[str(run_id)]) * 1000
            del self._tool_start_times[str(run_id)]
        
        
        # Get tool name
        tool_name = self._tool_names.get(str(run_id), kwargs.get("name", "unknown_tool"))
        self._tool_names.pop(str(run_id), None)


        # Create event
        event = AuditEvent(
            timestamp=datetime.now(),
            event_type=EventType.TOOL_SUCCESS,
            severity=EventSeverity.SUCCESS,
            message=f"Tool '{tool_name}' completed successfully",
            details={
                "tool_name": tool_name,
                "output": str(output)[:200],  # Limit output size
                "run_id": str(run_id)
            },
            duration_ms=duration_ms
        )

        self.audit_trail.add_event(event)

    def on_tool_error(
        self,
        error: Exception,
        run_id: Any,
        **kwargs: Any
    ) -> None:
        """Called when a tool encounters an error.

        Records tool error event with formatted error message and duration.

        Args:
            error: Exception raised during tool execution
            run_id: Unique identifier for this tool execution
            **kwargs: Additional keyword arguments (may contain 'name')

        Note:
            This is called automatically by LangChain's callback system.
            Error messages are formatted for user-friendliness and truncated.
        """
        # Calculate duration
        duration_ms = None
        if str(run_id) in self._tool_start_times:
            duration_ms = (time.time() - self._tool_start_times[str(run_id)]) * 1000
            del self._tool_start_times[str(run_id)]

        # Get tool name
        tool_name = self._tool_names.get(str(run_id), kwargs.get("name", "unknown_tool"))
        self._tool_names.pop(str(run_id), None)

        # Create user-friendly error message
        error_msg = self._format_error(error)

        # Create event
        event = AuditEvent(
            timestamp=datetime.now(),
            event_type=EventType.TOOL_ERROR,
            severity=EventSeverity.ERROR,
            message=f"Tool '{tool_name}' failed",
            details={
                "tool_name": tool_name,
                "error_type": type(error).__name__,
                "run_id": str(run_id)
            },
            error=error_msg,
            duration_ms=duration_ms
        )

        self.audit_trail.add_event(event)

    # ==================== LLM Events ====================

    def on_llm_start(
        self,
        serialized: Dict[str, Any],
        prompts: List[str],
        run_id: Any,
        **kwargs: Any
    ) -> None:
        """Called when LLM starts processing.

        Records LLM invocation event and begins timing.

        Args:
            serialized: Serialized LLM metadata (contains model info)
            prompts: List of prompts sent to the LLM
            run_id: Unique identifier for this LLM call
            **kwargs: Additional keyword arguments from LangChain

        Note:
            This is called automatically by LangChain's callback system.
        """
        self._llm_start_times[str(run_id)] = time.time()

        event = AuditEvent(
            timestamp=datetime.now(),
            event_type=EventType.LLM_CALL,
            severity=EventSeverity.INFO,
            message="LLM invoked",
            details={
                "model": serialized.get("id", ["unknown"])[0] if "id" in serialized else "unknown",
                "prompt_count": len(prompts),
                "run_id": str(run_id)
            }
        )

        self.audit_trail.add_event(event)

    def on_llm_end(
        self,
        response: Any,
        run_id: Any,
        **kwargs: Any
    ) -> None:
        """Called when LLM finishes processing.

        Records LLM response event with duration. If the response contains
        tool calls, records as AGENT_DECISION event type.

        Args:
            response: LLM response object (may contain tool_calls)
            run_id: Unique identifier for this LLM call
            **kwargs: Additional keyword arguments from LangChain

        Note:
            This is called automatically by LangChain's callback system.
            Automatically detects agent tool decisions from response.
        """
        # Calculate duration
        duration_ms = None
        if str(run_id) in self._llm_start_times:
            duration_ms = (time.time() - self._llm_start_times[str(run_id)]) * 1000
            del self._llm_start_times[str(run_id)]

        # Check if tool calls were made
        has_tool_calls = False
        tool_names = []

        if hasattr(response, 'generations'):
            for gen in response.generations:
                for g in gen:
                    if hasattr(g, 'message') and hasattr(g.message, 'tool_calls'):
                        if g.message.tool_calls:
                            has_tool_calls = True
                            tool_names = [tc['name'] for tc in g.message.tool_calls]

        message = "LLM response received"
        if has_tool_calls:
            message = f"Agent decided to use tools: {', '.join(tool_names)}"

        event = AuditEvent(
            timestamp=datetime.now(),
            event_type=EventType.AGENT_DECISION if has_tool_calls else EventType.LLM_CALL,
            severity=EventSeverity.INFO,
            message=message,
            details={
                "has_tool_calls": has_tool_calls,
                "tools": tool_names,
                "run_id": str(run_id)
            },
            duration_ms=duration_ms
        )

        self.audit_trail.add_event(event)

    def on_llm_error(
        self,
        error: Exception,
        run_id: Any,
        **kwargs: Any
    ) -> None:
        """Called when LLM encounters an error.

        Records LLM error event with formatted error message and duration.

        Args:
            error: Exception raised during LLM call
            run_id: Unique identifier for this LLM call
            **kwargs: Additional keyword arguments from LangChain

        Note:
            This is called automatically by LangChain's callback system.
            Error messages are formatted for user-friendliness.
        """
        duration_ms = None
        if str(run_id) in self._llm_start_times:
            duration_ms = (time.time() - self._llm_start_times[str(run_id)]) * 1000
            del self._llm_start_times[str(run_id)]

        error_msg = self._format_error(error)

        event = AuditEvent(
            timestamp=datetime.now(),
            event_type=EventType.LLM_CALL,
            severity=EventSeverity.ERROR,
            message="LLM call failed",
            details={
                "error_type": type(error).__name__,
                "run_id": str(run_id)
            },
            error=error_msg,
            duration_ms=duration_ms
        )

        self.audit_trail.add_event(event)

    # ==================== Helper Methods ====================

    def _format_error(self, error: Exception) -> str:
        """Format exception in user-friendly way.

        Converts exception to readable string with type and message,
        truncating long messages for readability.

        Args:
            error: Exception to format

        Returns:
            Formatted error string in format "ErrorType: message"

        Example:
            >>> callback._format_error(ValueError("Invalid input"))
            'ValueError: Invalid input'
        """
        error_type = type(error).__name__
        error_msg = str(error)

        # Truncate very long errors
        if len(error_msg) > 200:
            error_msg = error_msg[:197] + "..."

        return f"{error_type}: {error_msg}"