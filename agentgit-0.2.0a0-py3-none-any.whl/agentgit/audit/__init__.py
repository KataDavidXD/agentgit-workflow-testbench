"""Audit trail module for tracking and monitoring agent operations.

This module provides comprehensive audit trail capabilities for LangGraph agents,
including automatic callback-based event capture and user-friendly reporting.

Modules:
    audit_trail: Core audit trail data structures and event management
    audit_callback: LangChain callback handler for automatic event capture

Classes:
    EventType: Enumeration of audit event types
    EventSeverity: Severity levels for categorizing events
    AuditEvent: Single recorded event with metadata
    AuditTrail: Collection and manager for audit events
    AuditTrailCallback: LangChain callback handler for audit trail recording

Example:
    >>> from agentgit.audit import AuditTrail, AuditTrailCallback
    >>> from datetime import datetime
    >>>
    >>> # Create audit trail
    >>> trail = AuditTrail(session_id="session_123")
    >>> callback = AuditTrailCallback(trail)
    >>>
    >>> # Use with agent
    >>> agent = RollbackAgent(..., enable_audit_trail=True)
    >>> agent.run("Do something")
    >>>
    >>> # View audit trail
    >>> print(trail.format_user_display())
"""

from agentgit.audit.audit_trail import (
    EventType,
    EventSeverity,
    AuditEvent,
    AuditTrail,
)
from agentgit.audit.audit_callback import AuditTrailCallback

__all__ = [
    "EventType",
    "EventSeverity",
    "AuditEvent",
    "AuditTrail",
    "AuditTrailCallback",
]
