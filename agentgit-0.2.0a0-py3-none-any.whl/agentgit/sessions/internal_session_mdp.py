"""MDP-specific Internal Session implementation.

Extends the base InternalSession to support MDP runtime state and 
specialized branching logic.
"""

from dataclasses import dataclass, field
from typing import Dict, Any, Optional, List
from datetime import datetime
import uuid

from agentgit.sessions.internal_session import InternalSession
from agentgit.checkpoints.checkpoint import Checkpoint

@dataclass
class InternalSession_mdp(InternalSession):
    """Internal session with MDP runtime support.
    
    Attributes:
        workflow_version_id: The version of the workflow being executed.
        current_node_id: The ID of the current/next node to execute.
        workflow_variables: Context variables for the workflow.
        execution_path: History of visited node IDs.
    """
    workflow_version_id: Optional[str] = None
    current_node_id: Optional[str] = None
    workflow_variables: Dict[str, Any] = field(default_factory=dict)
    execution_path: List[str] = field(default_factory=list)
    
    @classmethod
    def create_branch_from_checkpoint(
        cls, 
        checkpoint: Checkpoint, 
        external_session_id: int, 
        parent_session_id: int
    ) -> "InternalSession_mdp":
        """Create a new MDP internal session branched from a checkpoint.
        
        Restores MDP-specific state (variables, node pointer) from metadata.
        
        Args:
            checkpoint: The checkpoint to branch from.
            external_session_id: ID of the external session.
            parent_session_id: ID of the parent internal session.
            
        Returns:
            New InternalSession_mdp branched from the checkpoint.
        """
        # Create basic structure using parent logic logic style
        # (We can't call super().create_branch... easily because it returns base class)
        
        # Extract MDP state from checkpoint metadata
        mdp_state = checkpoint.metadata.get("mdp_state", {})
        workflow_version = checkpoint.metadata.get("workflow_version", "1.0.0")
        node_id = checkpoint.metadata.get("node_id")
        
        # If specific mdp_state is missing, try to reconstruct or use defaults
        workflow_vars = mdp_state.get("workflow_variables", checkpoint.session_state.copy())
        current_node = node_id or mdp_state.get("current_node_id")
        path = mdp_state.get("execution_path", [])

        # Initialize new session
        session = cls(
            external_session_id=external_session_id,
            langgraph_session_id=f"mdp_branch_{uuid.uuid4().hex[:12]}",
            session_state=checkpoint.session_state.copy(),
            conversation_history=checkpoint.conversation_history.copy(),
            created_at=datetime.now(),
            is_current=True,
            parent_session_id=parent_session_id,
            branch_point_checkpoint_id=checkpoint.id,
            
            # MDP extensions
            workflow_version_id=workflow_version,
            current_node_id=current_node,
            workflow_variables=workflow_vars,
            execution_path=list(path) # Copy
        )
        
        # Metadata
        session.metadata = {
            "branched_from": checkpoint.checkpoint_name or f"Checkpoint {checkpoint.id}",
            "branch_created_at": datetime.now().isoformat(),
            "session_type": "mdp_workflow",
            "mdp_state": mdp_state # Preserve original state dict if needed
        }
        
        return session

