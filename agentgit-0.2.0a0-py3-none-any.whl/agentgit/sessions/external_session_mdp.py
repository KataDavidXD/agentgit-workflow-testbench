"""MDP-specific External Session implementation.

Extends the base ExternalSession to support workflow definitions and versioning
for the MDP-based agent system.
"""

from dataclasses import dataclass, field
from typing import Dict, Optional, Any
from agentgit.sessions.external_session import ExternalSession
from agentgit.core.workflow import WorkflowGraph

@dataclass
class ExternalSession_mdp(ExternalSession):
    """External session with MDP workflow support.
    
    Attributes:
        workflow_versions: Dictionary mapping version IDs to WorkflowGraphs.
        latest_version_id: ID of the most recent workflow version.
    """
    workflow_versions: Dict[str, WorkflowGraph] = field(default_factory=dict)
    latest_version_id: Optional[str] = None
    
    def add_workflow_version(self, graph: WorkflowGraph):
        """Register a new workflow version.
        
        Args:
            graph: The WorkflowGraph to register.
        """
        self.workflow_versions[graph.version] = graph
        self.latest_version_id = graph.version
        
    def get_workflow_version(self, version_id: str) -> Optional[WorkflowGraph]:
        """Retrieve a specific workflow version.
        
        Args:
            version_id: The version ID to retrieve.
            
        Returns:
            The WorkflowGraph if found, else None.
        """
        return self.workflow_versions.get(version_id)
        
    def get_latest_workflow(self) -> Optional[WorkflowGraph]:
        """Retrieve the latest workflow version.
        
        Returns:
            The latest WorkflowGraph if any exist.
        """
        if self.latest_version_id:
            return self.workflow_versions.get(self.latest_version_id)
        return None

