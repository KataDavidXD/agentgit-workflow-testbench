"""Workflow models for the MDP-based agent system.

Defines the structure of workflows including Nodes, Edges, and Graphs.
Designed to be serializable and compatible with existing session metadata storage.
"""

from dataclasses import dataclass, field
from typing import List, Dict, Any, Optional
import uuid

@dataclass
class WorkflowNode:
    """Represents a step in the workflow.
    
    Attributes:
        id: Unique identifier for the node.
        name: Human-readable name.
        tool_name: Name of the tool to execute for this node.
                   The tool must be registered with the ToolManager.
        metadata: Additional configuration.
    """
    id: str
    name: str
    tool_name: str
    metadata: Dict[str, Any] = field(default_factory=dict)

@dataclass
class WorkflowEdge:
    """Represents a transition between nodes.
    
    Attributes:
        source_id: ID of the source node.
        target_id: ID of the target node.
        condition_logic: Optional name of a registered condition function.
                         If None, edge is always taken (unless other edges have conditions).
        metadata: Additional configuration.
    """
    source_id: str
    target_id: str
    condition_logic: Optional[str] = None
    metadata: Dict[str, Any] = field(default_factory=dict)

@dataclass
class WorkflowGraph:
    """Collection of Nodes and Edges defining a workflow.
    
    Attributes:
        id: Unique identifier for the graph.
        nodes: Dictionary of nodes by ID.
        edges: List of edges.
        entry_point: ID of the starting node.
        version: Version string/ID.
    """
    id: str = field(default_factory=lambda: str(uuid.uuid4()))
    nodes: Dict[str, WorkflowNode] = field(default_factory=dict)
    edges: List[WorkflowEdge] = field(default_factory=list)
    entry_point: Optional[str] = None
    version: str = "1.0.0"
    
    def add_node(self, node: WorkflowNode):
        """Add a node to the graph."""
        self.nodes[node.id] = node
        if self.entry_point is None:
            self.entry_point = node.id
            
    def add_edge(self, edge: WorkflowEdge):
        """Add an edge to the graph."""
        self.edges.append(edge)
        
    def get_node(self, node_id: str) -> Optional[WorkflowNode]:
        """Get a node by ID."""
        return self.nodes.get(node_id)
        
    def get_outgoing_edges(self, node_id: str) -> List[WorkflowEdge]:
        """Get edges starting from the given node."""
        return [e for e in self.edges if e.source_id == node_id]
