"""MDP-based Rollback Agent.

This agent executes LangGraph-style workflows using a Markov Decision Process approach.
It delegates workflow logic to NodeManager and persistence to CheckpointManager_mdp.
"""

from typing import Any, Dict, Optional

from agentgit.sessions.external_session_mdp import ExternalSession_mdp
from agentgit.sessions.internal_session_mdp import InternalSession_mdp
from agentgit.managers.node_manager import NodeManager
from agentgit.managers.checkpoint_manager_mdp import CheckpointManager_mdp

class RollbackAgent_mdp:
    """Agent for executing MDP workflows with rollback capabilities."""
    
    def __init__(
        self,
        external_session: ExternalSession_mdp,
        internal_session: InternalSession_mdp,
        node_manager: NodeManager,
        checkpoint_manager: CheckpointManager_mdp,
    ):
        """Initialize the MDP agent.
        
        Args:
            external_session: The definition container.
            internal_session: The runtime state.
            node_manager: Manager for node execution.
            checkpoint_manager: Manager for checkpointing.
        """
        self.external_session = external_session
        self.internal_session = internal_session
        self.node_manager = node_manager
        self.checkpoint_manager = checkpoint_manager
        
    def run(self, input_data: Dict[str, Any]) -> Dict[str, Any]:
        """Execute the workflow.
        
        Args:
            input_data: Input variables for the workflow.
            
        Returns:
            Final workflow variables/result.
        """
        # Initialize/Update variables from input
        state = self.node_manager.get_mdp_state(self.internal_session)
        state["workflow_variables"].update(input_data)
        self.node_manager.update_mdp_state(self.internal_session, state)
        
        # Main Execution Loop
        while True:
            state = self.node_manager.get_mdp_state(self.internal_session)
            current_node_id = state.get("current_node_id")
            
            if not current_node_id:
                # No current node means workflow is done or not started
                break
                
            # 1. Create Node Checkpoint (Snapshot BEFORE execution)
            # Get current tool track position to mark rollback point
            track_pos = self.node_manager.tool_manager.get_tool_track_position()
            
            node_cp = self.checkpoint_manager.create_node_checkpoint(
                self.internal_session,
                node_id=current_node_id,
                workflow_version=self.internal_session.workflow_version_id or "1.0.0",
                tool_track_position=track_pos
            )
            
            # 2. Execute Node
            try:
                result = self.node_manager.execute_node(self.internal_session)
            except Exception as e:
                print(f"Error executing node {current_node_id}: {e}")
                # Capture error state/checkpoint?
                break
                
            # 3. Transition
            next_node_id = self.node_manager.transition(self.internal_session, result)
            
            if not next_node_id:
                # End of workflow
                break
                
        return self.node_manager.get_mdp_state(self.internal_session)["workflow_variables"]

    def rollback_to_checkpoint(self, checkpoint_id: int) -> Optional[InternalSession_mdp]:
        """Rollback to a specific checkpoint, reversing tool effects.
        
        Encapsulates the full rollback logic: state restoration + side-effect reversal.
        
        Args:
            checkpoint_id: ID of the checkpoint to rollback to.
            
        Returns:
            The new InternalSession_mdp if successful, None otherwise.
        """
        # 1. Get Checkpoint
        checkpoint = self.checkpoint_manager.get_checkpoint(checkpoint_id)
        if not checkpoint:
            return None
            
        # 2. Identify tool track position
        # This is the position *at the time of checkpoint creation*
        # We want to reverse everything that happened *after* this point.
        target_position = checkpoint.get_tool_track_position()
        
        # 3. Reverse effects
        # Rollback tools from current end down to target_position
        tool_mgr = self.node_manager.tool_manager
        tool_mgr.rollback_tools_from_position(target_position)
        
        # 4. Branch/Restore State
        # Use InternalSession_mdp factory method directly
        new_session = InternalSession_mdp.create_branch_from_checkpoint(
            checkpoint, 
            self.external_session.id,
            self.internal_session.id
        )
        
        # 5. Update internal session reference
        if new_session:
            self.internal_session = new_session
            
        return new_session
